﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assessment;

namespace Assessment_Tests.Helpers
{
    public static class Helper_KnownConstituencyDataRepository
    {
        public static Constituency GetKnownSunderland()
        {
            // Build a known constituency object and return this for use in various test methods
            var constituency = new Constituency("Sunderland");

            // instantiate the candidate list 
            constituency.candidateList = new CandidateList();
            constituency.candidateList.candidateDetails = new List<CandidateDetails>();

            // Build a known intital candidate list for this known constituency (selection of data from Sunderland.xml)
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("Fred Bloggs", "Conservative", 135, "Sunderland"));
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("Jane Smith", "Green", 200, "Sunderland"));
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("Harry Knowles", "Congress", 195, "Sunderland"));
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("Daisy Knightly", "4Youth", 125, "Sunderland"));
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("Jamie Cook", "Liberty", 225, "Sunderland"));
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("David Yeshi", "New World", 200, "Sunderland"));

            // Build the known candidate winner
            constituency.candidatewinner = new CandidateDetails("Jamie Cook", "Liberty", 225, "Sunderland");

            return constituency;
        }

        public static Constituency GetKnownNewcastle()
        {
            // Build a known constituency object and return this for use in various test methods
            var constituency = new Constituency("Newcastle");

            // instantiate the candidate list 
            constituency.candidateList = new CandidateList();
            constituency.candidateList.candidateDetails = new List<CandidateDetails>();

            // Build a known intital candidate list for this known constituency (selection of data from Sunderland.xml)
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("Johnny White", "Conservative", 165, "Newcastle"));
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("David Wale", "Green", 175, "Newcastle"));
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("Daniel Smith", "Congress", 180, "Newcastle"));
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("Keiran James", "4Youth", 175, "Newcastle"));
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("Chris Lee", "Liberty", 182, "Newcastle"));
            constituency.candidateList.candidateDetails.Add(new CandidateDetails("Sandra Lee", "New World", 203, "Newcastle"));

            // Build the known candidate winner
            constituency.candidatewinner = new CandidateDetails("Sandra Lee", "New World", 203, "Newcastle");

            return constituency;
        }

        public static List<CandidateDetails> GetTwoElectedCandidates()
        {
            // instantiate list
            var list = new List<CandidateDetails>();

            // Adding Constituency to the List
            list.Add(new CandidateDetails("Sandra Lee", "New World", 203, "Newcastle"));
            list.Add(new CandidateDetails("Jamie Cook", "Liberty", 225, "Sunderland"));

            // return the list
            return list;            
        }

        public static List<Party> GetSunderlandParty()
        {
            // instantiate list
            var list = new List<Party>();

            // Adding the parties in Sunderland constitunecy to the list
            list.Add(new Party("Conservative", 135));
            list.Add(new Party("Green", 200));
            list.Add(new Party("Congress", 195));
            list.Add(new Party("4Youth", 125));
            list.Add(new Party("Liberty", 225));
            list.Add(new Party("New World", 200));

            // return list
            return list;
        }

        public static List<Party> GetNewcastleParty()
        {
            // instantiate list
            var list = new List<Party>();

            // Adding the parties in Sunderland constitunecy to the list
            list.Add(new Party("Conservative", 165));
            list.Add(new Party("Green", 175));
            list.Add(new Party("Congress", 180));
            list.Add(new Party("4Youth", 175));
            list.Add(new Party("Liberty", 182));
            list.Add(new Party("New World", 203));

            // return list
            return list;

        }
    }
}
