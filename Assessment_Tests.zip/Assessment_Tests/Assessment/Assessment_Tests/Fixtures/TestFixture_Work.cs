﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assessment_Tests.Dependencies;
using Assessment_Tests.Helpers;
using TestedClass = Assessment.Work;

namespace Assessment_Tests.Fixtures
{
    [TestClass]
    public class TestFixture_Work
    {
        [TestMethod]
        public void Test_ReadData_Method_Correct_Constituency_Returned()
        {
            // Arrange
            // Use the ConstituencyFileReaderReturnKNownSunderland implementation of IConstituencyFileReader which simply returns a
            // known Constituency instance from its ReadConstituencyDataFromFile() method, note that no ConfigRecord if actually
            // needed so this can be passed as a null
            var ioHandler = new ConstituencyFileReaderReturnKnownSunderland();

            // Instantiate a Work object
            var testedClass = new TestedClass(null, ioHandler);

            // Use the helper class to get known Sunderland constituency instance
            var expectedConstituency = Helper_KnownConstituencyDataRepository.GetKnownSunderland();

            // Act
            // Call the ReadData() method of the Work instance and the data held in the constituency returned from this should
            // be identical to the data held in the expected constituency instance
            var actualConstituency = testedClass.ReadData();

            // Assert
            // Check each property of the expected and actual constituency instances to make sure they contain the same data,
            // note here that it would be a good idea to give the candidate list class a way to check its value equality
            // with another candudatelist object via the overriding of its Equals() method

            // First check Constituency Name property
            Assert.AreEqual(expectedConstituency.name, actualConstituency.name);
            
            // Next check the lengths of the candidate list
            Assert.AreEqual(expectedConstituency.candidateList.candidateDetails.Count, actualConstituency.candidateList.candidateDetails.Count);

            // Check the candidate winner of the constituency
            Assert.AreEqual(expectedConstituency.candidatewinner.name, actualConstituency.candidatewinner.name);
            Assert.AreEqual(expectedConstituency.candidatewinner.party, actualConstituency.candidatewinner.party);
            Assert.AreEqual(expectedConstituency.candidatewinner.votes, actualConstituency.candidatewinner.votes);

            // Now iterate through the candidate list and check for data equality
            for(var i=0; i<expectedConstituency.candidateList.candidateDetails.Count; i++)
            {
                Assert.AreEqual(expectedConstituency.candidateList.candidateDetails[i].name, actualConstituency.candidateList.candidateDetails[i].name);
                Assert.AreEqual(expectedConstituency.candidateList.candidateDetails[i].party, actualConstituency.candidateList.candidateDetails[i].party);
                Assert.AreEqual(expectedConstituency.candidateList.candidateDetails[i].votes, actualConstituency.candidateList.candidateDetails[i].votes);

            }
        }
    }
}
