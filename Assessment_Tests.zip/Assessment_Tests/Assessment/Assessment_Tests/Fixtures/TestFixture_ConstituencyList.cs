﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assessment;
using Assessment_Tests.Helpers;
using Assessment_Tests.Dependencies;
using TestedClass = Assessment.ConstituencyList;

namespace Assessment_Tests.Fixtures
{
    [TestClass]
    public class TestFixture_ConstituencyList
    {
        [TestMethod]
        public void Test_ConstituencyList_Class_ContainsZero_ConstituencyList()
        {
            // Arrange
            // Instantiate Constituency object
            var testedClass = new TestedClass();

            // Act
            // since no constituency object has not been added it should return a list count of 0
            var actualConstituencyList = testedClass.constituencies.Count;

            // Assert
            // actual constituency list should return 0
            Assert.AreEqual(0, actualConstituencyList);
        }

    }
}
