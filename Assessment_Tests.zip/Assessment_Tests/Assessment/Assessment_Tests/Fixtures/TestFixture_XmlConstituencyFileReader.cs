﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assessment;
using Assessment_Tests.Helpers;
using TestedClass = Assessment.XmlConstituencyFileReader;

namespace Assessment_Tests.Fixtures
{
    [TestClass]
    public class TestFixture_XmlConstituencyFileReader
    {
        TestedClass testedClass= null;
        [TestCleanup]
        public void TestsCleanup()
        {
            testedClass = null;
        }

        [TestMethod]
        public void Test_ReadConstituencyDataFromFile_Method_File_Not_Exist()
        {
            // Arrange
            // A file with this name does not exist
            var filename = "Does_Not_Exist";

            // Instantiate an XMLConstituencyFileReader object
            testedClass = new TestedClass();

            // Act
            var actualConstituency = testedClass.ReadConstituencyDataFromFile(new ConfigRecord(filename));

            // Assert
            Assert.IsNull(actualConstituency);
        }

        [TestMethod]
        public void Test_ReadConstituencyDataFromFile_Method_File_Sunderland_Exists_Is_Valid()
        {
            Helper_Test_ReadConstituencyDataFromFile_Method_File_Exists_Is_Valid("Sunderland.xml", Helper_KnownConstituencyDataRepository.GetKnownSunderland());
        }

        [TestMethod]
        public void Test_ReadConstituencyDataFromFile_Method_File_Newcastle_Exists_Is_Valid()
        {
            Helper_Test_ReadConstituencyDataFromFile_Method_File_Exists_Is_Valid("Newcastle.xml", Helper_KnownConstituencyDataRepository.GetKnownNewcastle());
        }

        [TestMethod]
        [ExpectedException(typeof(System.Xml.XmlException))]
        public void Test_ReadConstituencyDataFromFile_Method_File_Exists_Is_Invalid()
        {
            // Arrange
            // A file with this name exist and contains a constituency that has the same data as the expected constituency
            // object instance
            var fileName = "InvalidConstituency.xml";

            // Intantiate an XMLConstituencyFileReader object
            testedClass = new TestedClass();

            // Act 
            // Call the ReadConstituencyDataFromFile() method to load and process an invalid XML format, this should
            // throw a System.Xml.XmlException
            var actualConstituency = testedClass.ReadConstituencyDataFromFile(new ConfigRecord(fileName));

            // Assert
            // Should not reach here due to exception being raised, if reached then force the test to fail
            Assert.Fail("ERROR: should have thrown System.Xml.XmlException before reaching here!");
        }
        


        private void Helper_Test_ReadConstituencyDataFromFile_Method_File_Exists_Is_Valid(string filename, Constituency expectedConstituency)
        {
            // Arrange
            // Instantiate an XmlConstituencyFileReader object
            testedClass = new TestedClass();

            // Act
            // Call the ReadConstituencyDataFromFile() method to load and process the known constituency from the XML format
            var actualConstituency = testedClass.ReadConstituencyDataFromFile(new ConfigRecord(filename));

            // Assert
            // Check each property of the expected and actual constituency instances to make sure that they contain the same data,
            // note here that it would be a good idea to give the Candidate List class a way to check its data value equality
            // with another candidate list object via overriding of its Equals() method

            // First check Constituency name property
            Assert.AreEqual(expectedConstituency.name, actualConstituency.name);

            // Next check the lengths of the candidate list
            Assert.AreEqual(expectedConstituency.candidateList.candidateDetails.Count, actualConstituency.candidateList.candidateDetails.Count);

            // Check the candidate winner of the constituency
            Assert.AreEqual(expectedConstituency.candidatewinner.name, actualConstituency.candidatewinner.name);
            Assert.AreEqual(expectedConstituency.candidatewinner.party, actualConstituency.candidatewinner.party);
            Assert.AreEqual(expectedConstituency.candidatewinner.votes, actualConstituency.candidatewinner.votes);

            // Now iterate through the candidate list and check for data equality
            for (var i = 0; i < expectedConstituency.candidateList.candidateDetails.Count; i++)
            {
                Assert.AreEqual(expectedConstituency.candidateList.candidateDetails[i].name, actualConstituency.candidateList.candidateDetails[i].name);
                Assert.AreEqual(expectedConstituency.candidateList.candidateDetails[i].party, actualConstituency.candidateList.candidateDetails[i].party);
                Assert.AreEqual(expectedConstituency.candidateList.candidateDetails[i].votes, actualConstituency.candidateList.candidateDetails[i].votes);

            }
        }
    }
}
