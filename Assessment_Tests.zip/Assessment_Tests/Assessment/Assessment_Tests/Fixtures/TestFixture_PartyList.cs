﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assessment;
using Assessment_Tests.Dependencies;
using Assessment_Tests.Helpers;
using TestedClass = Assessment.PartyList;

namespace Assessment_Tests.Fixtures
{
    [TestClass]
    public class TestFixture_PartyList
    {
        [TestMethod]
        public void Test_AddVotes_Method_Compare_TotalVotes()
        {
            // Arrange
            // Instantiate Constituency object and XmlPartyReader
            var testedClass = new TestedClass();
            var partyReader = new XmlPartyReader();

            // act
            var sunderlandPartyList = partyReader.ReadParty(new ConfigRecord("Sunderland.xml"));
            var newcastlePartyList = partyReader.ReadParty(new ConfigRecord("Newcastle.xml"));

            // Add the sunderland votes
            foreach (var p in sunderlandPartyList)
            {
                testedClass.AddVotes(p);                   
            }

            // Add the Newcastle votes
            foreach (var p in newcastlePartyList)
            {
                testedClass.AddVotes(p);
            }

            // Assert
            // iterate
            foreach(var party in testedClass.Parties)
            {
                string name = party.PartyName;
                switch(name)
                {
                    case "Conservative":
                        Assert.AreEqual(party.PartyVotes, 300);
                        break;
                    case "Green":
                        Assert.AreEqual(party.PartyVotes, 375);
                        break;
                    case "Congress":
                        Assert.AreEqual(party.PartyVotes, 375);
                        break;
                    case "4Youth":
                        Assert.AreEqual(party.PartyVotes, 300);
                        break;
                    case "Liberty":
                        Assert.AreEqual(party.PartyVotes, 407);
                        break;
                    case "New World":
                        Assert.AreEqual(party.PartyVotes, 403);
                        break;

                }
            }
        }
    }
}
