﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assessment;

namespace Assessment_Tests.Dependencies
{
    class PCQueueNullDequeued:IPCQueue
    {
        public void enqueueItem(Work item)
        {
            // can be left as empty stub since it is not called
        }

        public Work dequeueItem()
        {
            // A null is dequeued
            return null;
        }
    }
}
