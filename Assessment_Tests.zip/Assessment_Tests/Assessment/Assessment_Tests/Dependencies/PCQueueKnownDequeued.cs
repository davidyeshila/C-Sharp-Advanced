﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assessment;

namespace Assessment_Tests.Dependencies
{
    public class PCQueueKnownDequeued: IPCQueue
    {
        public void enqueueItem(Work item)
        {
            // can be left as an empty stub since it is not called
        }

        public Work dequeueItem()
        {
            // Dequeue a dummy Work instance
            var work = new Work(new ConfigRecord("Sunderland.xml"), new ConstituencyFileReaderReturnKnownSunderland());
            return work;
        }

    }
}
