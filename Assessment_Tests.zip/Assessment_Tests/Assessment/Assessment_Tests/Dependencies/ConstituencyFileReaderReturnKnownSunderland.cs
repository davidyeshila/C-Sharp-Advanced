﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assessment;
using Assessment_Tests.Helpers;

namespace Assessment_Tests.Dependencies
{
    public class ConstituencyFileReaderReturnKnownSunderland: IConstituencyFileReader
    {
        public Constituency ReadConstituencyDataFromFile(ConfigRecord configRecord)
        {
            // Use helper class to get a known sunderland constituency instance
            return Helper_KnownConstituencyDataRepository.GetKnownSunderland();
        }
    }
}
