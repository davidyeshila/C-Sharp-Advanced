﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assessment;

namespace Assessment_Tests.Dependencies
{
    public class PCQueueCallEnqueueItem: IPCQueue
    {
        // This property is used to record the number of time the EnqueueItem method has
        // been called
        public int EnqueueItemCallCount { get; private set; }

        // Constructor
        public PCQueueCallEnqueueItem()
        {
            // Initially no calls to EnqueueItem method
            EnqueueItemCallCount = 0;
        }

        public void enqueueItem(Work item)
        {
            // When called, increment the call count property to record how many times
            // the method has been called
            EnqueueItemCallCount++;
        }

        public Work dequeueItem()
        {
            // Can be left as an empty stub since it is not called but must return null
            return null;
        }
    }
}
