﻿namespace Assessment
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnViewConstituencies = new System.Windows.Forms.Button();
            this.btnElectedCandidates = new System.Windows.Forms.Button();
            this.btnParties = new System.Windows.Forms.Button();
            this.btnElectionWinner = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnConfigData = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(51, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(294, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please select what you would like to view";
            // 
            // btnViewConstituencies
            // 
            this.btnViewConstituencies.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnViewConstituencies.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnViewConstituencies.Location = new System.Drawing.Point(103, 155);
            this.btnViewConstituencies.Name = "btnViewConstituencies";
            this.btnViewConstituencies.Size = new System.Drawing.Size(172, 41);
            this.btnViewConstituencies.TabIndex = 1;
            this.btnViewConstituencies.Text = "Constituencies";
            this.btnViewConstituencies.UseVisualStyleBackColor = true;
            this.btnViewConstituencies.Visible = false;
            this.btnViewConstituencies.Click += new System.EventHandler(this.btnViewConstituency);
            // 
            // btnElectedCandidates
            // 
            this.btnElectedCandidates.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnElectedCandidates.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnElectedCandidates.Location = new System.Drawing.Point(103, 208);
            this.btnElectedCandidates.Name = "btnElectedCandidates";
            this.btnElectedCandidates.Size = new System.Drawing.Size(172, 41);
            this.btnElectedCandidates.TabIndex = 2;
            this.btnElectedCandidates.Text = "The Elected Candidates";
            this.btnElectedCandidates.UseVisualStyleBackColor = true;
            this.btnElectedCandidates.Visible = false;
            this.btnElectedCandidates.Click += new System.EventHandler(this.btnElectedCandidates_Click);
            // 
            // btnParties
            // 
            this.btnParties.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnParties.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnParties.Location = new System.Drawing.Point(103, 261);
            this.btnParties.Name = "btnParties";
            this.btnParties.Size = new System.Drawing.Size(172, 41);
            this.btnParties.TabIndex = 3;
            this.btnParties.Text = "Parties in this Election";
            this.btnParties.UseVisualStyleBackColor = true;
            this.btnParties.Visible = false;
            this.btnParties.Click += new System.EventHandler(this.btnParties_Click);
            // 
            // btnElectionWinner
            // 
            this.btnElectionWinner.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnElectionWinner.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnElectionWinner.Location = new System.Drawing.Point(103, 314);
            this.btnElectionWinner.Name = "btnElectionWinner";
            this.btnElectionWinner.Size = new System.Drawing.Size(172, 41);
            this.btnElectionWinner.TabIndex = 4;
            this.btnElectionWinner.Text = "Election Winner";
            this.btnElectionWinner.UseVisualStyleBackColor = true;
            this.btnElectionWinner.Visible = false;
            this.btnElectionWinner.Click += new System.EventHandler(this.btnElectionWinner_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = global::Assessment.Properties.Resources.rsz_election;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(122, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(134, 50);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btnConfigData
            // 
            this.btnConfigData.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnConfigData.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnConfigData.Location = new System.Drawing.Point(103, 102);
            this.btnConfigData.Name = "btnConfigData";
            this.btnConfigData.Size = new System.Drawing.Size(172, 41);
            this.btnConfigData.TabIndex = 7;
            this.btnConfigData.Text = "Config Data";
            this.btnConfigData.UseVisualStyleBackColor = true;
            this.btnConfigData.Click += new System.EventHandler(this.btnConfigData_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(392, 368);
            this.Controls.Add(this.btnConfigData);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnElectionWinner);
            this.Controls.Add(this.btnParties);
            this.Controls.Add(this.btnElectedCandidates);
            this.Controls.Add(this.btnViewConstituencies);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Home_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnViewConstituencies;
        private System.Windows.Forms.Button btnElectedCandidates;
        private System.Windows.Forms.Button btnParties;
        private System.Windows.Forms.Button btnElectionWinner;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnConfigData;
    }
}