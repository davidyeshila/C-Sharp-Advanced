﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment
{
    /// <summary>
    /// This class holds the list of all configRecords(filename)
    /// </summary>
    public class ConfigData
    {
        public List<ConfigRecord> configRecords { get; set; }

        public int NextRecord {get; set; }

        public ConfigData()
        {
            this.NextRecord = 0;
            configRecords = new List<ConfigRecord>();
        }
    }
}
