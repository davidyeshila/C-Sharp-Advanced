﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment
{
    public class CandidateDetails
    {
        public string name { get; set; }
        public string party { get; set; }
        public int votes { get; set; }
        private string constituencyName;
        public CandidateDetails(string name, string party, int votes, string constituencyName)
        {
            this.name = name;
            this.party = party;
            this.votes = votes;
            this.constituencyName = constituencyName;
        }

        // returns the candidate's name
        public override string ToString()
        {
            return name;
        }

        /// <summary>
        /// Displays the candidate's details in an aprropriate formate
        /// </summary>
        /// <returns>
        /// returns the candidate's details in a string format
        /// </returns>
        public string displayCandidate()
        {
            return String.Format("Constituency:{0,10}\nParty:{1,10}\nVotes:{2,10}",constituencyName,party, votes);
        }
    }
}
