﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment
{
    public partial class PartiesForm : Form
    {
        PartyList partyList;
        public PartiesForm(PartyList partyList)
        {
            InitializeComponent();
            this.partyList = partyList;
        }

        /// <summary>
        /// Displays the list of Parties on Load
        /// </summary>
        private void PartiesForm_Load(object sender, EventArgs e)
        {
            // iterates the party list and displays it to the user
            foreach (var p in partyList.Parties)
            {
               lblParties.Text+= p.ToString() + Environment.NewLine;
            }
        }

        private void PartiesForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
    }
}
