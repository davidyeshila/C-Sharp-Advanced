﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Assessment
{
    public class Constituency
    {
        public string name { get; set; }
        public CandidateDetails candidatewinner;
        public CandidateList candidateList { get; set; }
        
        public Constituency(string name)
        {
            this.name = name;
        }

        public override string ToString()
        {
            return name;
        }


    }
}
