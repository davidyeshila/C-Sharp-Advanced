﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Threading;

namespace Assessment
{
    public partial class ConstituenciesForm : Form
    {
        /// <summary>
        /// instantiating objects which will be used in this form
        /// </summary>
        public IConstituencyFileReader IOhandler { get; set; }
        private ConstituencyList constituencyList;

        public ConstituenciesForm(IConstituencyFileReader IOhandler, ConstituencyList constituencyList)
        {            
            InitializeComponent();
            this.IOhandler = IOhandler;
            this.constituencyList = constituencyList;
        }

        /// <summary>
        /// when the form loads it clears the listbox
        /// and adds the constituencies to the dropdown box
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
             lstCandidates.Items.Clear();
          
            // Having finished generating the data we can now fill the combobox
            foreach(var constituency in constituencyList.constituencies)
            {
                cmbConstituencies.Items.Add(constituency);
                
            }            
        }
      
        /// <summary>
        /// Displays the canidates in the constituency when an item is selected in the combobox
        /// </summary>
        private void cmbConstituencies_SelectedIndexChanged(object sender, EventArgs e)
        {
            // If an item is constituency is selected from the combo box then the listbox is 
            // updated with the list of all the candidates in the selected constituency           
                lstCandidates.Visible = true;
                label2.Visible = true;
                lstCandidates.Items.Clear();

                Constituency constituency = (Constituency)cmbConstituencies.SelectedItem;
                
                // looping through the candidates list
                foreach(CandidateDetails candidates in constituency.candidateList.candidateDetails)
                {
                    lstCandidates.Items.Add(candidates);
                }
            
        }
        
        /// <summary>
        /// Displays the candidate details when a candidate is selected from the listbox
        /// </summary>
        private void lstCandidates_SelectedIndexChanged(object sender, EventArgs e)
        {            
            // When a canidate is selected from the list it shows the candidates details
            lblCandidateDetails.Visible = true;
            label3.Visible = true;

            CandidateDetails candidate = (CandidateDetails)lstCandidates.SelectedItem;
            string detail = candidate.displayCandidate();

            lblCandidateDetails.Text = detail;

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            btnBack.DialogResult = DialogResult.OK;
        }

        private void ConstituenciesForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
    }
}
