﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment
{
    public interface IUserInterface
    {
        //void SetUpConfigData();
        void RunProducerConsumer();
        void LoadParties();
    }
}
