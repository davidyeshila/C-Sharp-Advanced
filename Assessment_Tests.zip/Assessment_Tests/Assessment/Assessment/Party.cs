﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment
{
    public class Party
    {
        public string PartyName { get; private set; }
        public int PartyVotes { get; set; }

        public Party(string name, int votes)
        {
            PartyName = name;
            PartyVotes = votes;
        }

        /// <summary>
        /// Adds the votes to the pary
        /// </summary>
        /// <param name="votes"></param>
        public void AddVotes(int votes)
        {
            PartyVotes += votes;
        }

        public override string ToString()
        {
            return String.Format("{0,-20}{1,25}", PartyName, PartyVotes+" votes");
        }
    }
}
