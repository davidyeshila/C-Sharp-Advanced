﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Threading;

namespace Assessment
{
    public partial class Home : Form, IUserInterface
    {
        // Instantiating objects to be used
        private ConfigData configData;
        private ConstituencyList constituencyList;
        XmlConstituencyFileReader IOhandler = new XmlConstituencyFileReader();
        XmlPartyReader partyHandler = new XmlPartyReader();
        PartyList partyList = new PartyList();

        public Home()
        {
            InitializeComponent();
        }

        private void Home_Load(object sender, EventArgs e)
        {
        }

        // config button needs to be selected first
        private void btnConfigData_Click(object sender, EventArgs e)
        {
            // new instance of a configdata
            configData = new ConfigData();
            
            // opening a file dialog to add the constituency xml files to the system
            OpenFileDialog openfile = new OpenFileDialog();

            openfile.Filter = " Xml files (*.xml)|*.xml";
            openfile.Multiselect = true;

            if (openfile.ShowDialog() == DialogResult.OK)
            {
                foreach (var file in openfile.FileNames)
                {
                    configData.configRecords.Add(new ConfigRecord(file));
                }
            }

            // Runs the producerconsumer and loads the parties 
            // once the config Data has been set up
            RunProducerConsumer();
            LoadParties();

            // displays the buttons in the form once the ProducerConsumer and Load Parties method
            // has been called
            btnElectedCandidates.Visible = true;
            btnViewConstituencies.Visible = true;
            btnParties.Visible = true;
            btnElectionWinner.Visible = true;
        }
        // Loads the parties to the partyList
        public void LoadParties()
        {
            //if (partyList.Parties.Count == 0)
            //{
                foreach (var configRecord in configData.configRecords)
                {
                    var parties = partyHandler.ReadParty(configRecord);
                    foreach (var party in parties)
                    {
                        partyList.AddVotes(party);
                    }
                }
            //}
            //else
            //{
            //    foreach (var configRecord in configData.configRecords)
            //    {
            //        partyList.Parties = partyHandler.ReadParty(configRecord);
            //    }
            //}
        }

        public void RunProducerConsumer()
        {
            // Create constituency list to hold the individual constituency objects read from datasets
            constituencyList = new ConstituencyList();

            // Create a progress manager with a number of file to process
            ProgressManager progManager = new ProgressManager(configData.configRecords.Count);

            // Create a PCQueue instance and give it a capacity of 4
            var pcQueue = new PCQueue(4);

            // Create 2 Producer and consumer instances, these will begin executing on
            // their respective threads as soon as they are instantiated
            Producer[] producers = {new Producer("P1", pcQueue, configData, IOhandler),
                                   new Producer("P2",pcQueue,configData,IOhandler)};

            Consumer[] consumers = {new Consumer("C1",pcQueue, constituencyList, progManager),
                                   new Consumer("C2", pcQueue,constituencyList,progManager)};

            while (progManager.ItemsRemaining > 0) ;

            // Deactivate the pcQueue so it does not prevent waiting producer and/or consumer threads from completing
            pcQueue.Active = false;

            // Iterate through producers and signal them to finish
            foreach (var p in producers)
            {
                p.Finished = true;
            }

            // Iterate through consumers and signal them to finish
            foreach (var c in consumers)
            {
                c.Finished = true;
            }

            // We need to ensure that no thread waiting on Monitor.Wait() is stranded with
            // no Monitor.Pulse() now possible since all producer and consumer threads have
            // been signalled to stop, in the worse case all such threads could be stranded
            // so pulse that many times to ensure enough pulses are made available (or the 
            // program can halt erroneosly), wasted pulses are simply ignored

            for (int i = 0; i < (Consumer.RunningThreads + Producer.RunningThreads); i++)
            {
                lock (pcQueue)
                {
                    // Pulse the PCQueue to signal any waiting threads
                    Monitor.Pulse(pcQueue);

                    // Give a short break to the main thread so the pulses have time to be
                    // detected by any potential waiting producer and/or consumer threads
                    Thread.Sleep(100);
                }
            }

            // Once all producer and consumer threads have finally finished we can gracefully
            // shutdown the main thread, this is achieved by spinning on a while() loop until
            // there are no running threads, in this case we don not mind the main thread
            // spinning as we are about to shutdown the program
            while ((Producer.RunningThreads > 0) || (Consumer.RunningThreads > 0)) ; // Wait by spinning
        }

        private void btnViewConstituency(object sender, EventArgs e)
        {

            // Display the Constituencies Form
            ConstituenciesForm constituencyForm = new ConstituenciesForm(IOhandler, constituencyList);

            // opens the form until a dialog result(ok) is invoked
            while (constituencyForm.ShowDialog() != DialogResult.OK) ;
                
           
        }

        private void btnElectedCandidates_Click(object sender, EventArgs e)
        {
            // Display the Elected Candidates Form
            Elected_Candidates electedCandidForm = new Elected_Candidates(constituencyList);

            // opens the form until a dialog result(ok) is invoked
            while (electedCandidForm.ShowDialog() != DialogResult.OK) ;
        }

        private void btnParties_Click(object sender, EventArgs e)
        {
            // Displays the Parties Form
            PartiesForm partiesForm = new PartiesForm(partyList);

            // opens the form until a dialog result(ok) is invoked
            while (partiesForm.ShowDialog() != DialogResult.OK) ;
        }

        private void btnElectionWinner_Click(object sender, EventArgs e)
        {
            ElectionWinnerForm electionWinnerForm = new ElectionWinnerForm(partyList);
            // opens the form until a dialog result(ok) is invoked
            while (electionWinnerForm.ShowDialog() != DialogResult.OK) ;
        }     
    }
}
