﻿namespace Assessment
{
    partial class ConstituenciesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbConstituencies = new System.Windows.Forms.ComboBox();
            this.lstCandidates = new System.Windows.Forms.ListBox();
            this.lblCandidateDetails = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(143, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please Select a Constituency";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label2.Location = new System.Drawing.Point(33, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Candidates";
            this.label2.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label3.Location = new System.Drawing.Point(241, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Details";
            this.label3.Visible = false;
            // 
            // cmbConstituencies
            // 
            this.cmbConstituencies.BackColor = System.Drawing.Color.White;
            this.cmbConstituencies.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbConstituencies.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.cmbConstituencies.FormattingEnabled = true;
            this.cmbConstituencies.Location = new System.Drawing.Point(181, 50);
            this.cmbConstituencies.Name = "cmbConstituencies";
            this.cmbConstituencies.Size = new System.Drawing.Size(126, 24);
            this.cmbConstituencies.TabIndex = 3;
            this.cmbConstituencies.SelectedIndexChanged += new System.EventHandler(this.cmbConstituencies_SelectedIndexChanged);
            // 
            // lstCandidates
            // 
            this.lstCandidates.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lstCandidates.FormattingEnabled = true;
            this.lstCandidates.ItemHeight = 16;
            this.lstCandidates.Location = new System.Drawing.Point(37, 116);
            this.lstCandidates.Name = "lstCandidates";
            this.lstCandidates.Size = new System.Drawing.Size(166, 100);
            this.lstCandidates.TabIndex = 4;
            this.lstCandidates.Visible = false;
            this.lstCandidates.SelectedIndexChanged += new System.EventHandler(this.lstCandidates_SelectedIndexChanged);
            // 
            // lblCandidateDetails
            // 
            this.lblCandidateDetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCandidateDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblCandidateDetails.Location = new System.Drawing.Point(244, 116);
            this.lblCandidateDetails.Name = "lblCandidateDetails";
            this.lblCandidateDetails.Size = new System.Drawing.Size(204, 104);
            this.lblCandidateDetails.TabIndex = 5;
            this.lblCandidateDetails.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = global::Assessment.Properties.Resources.rsz_election;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(364, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(134, 50);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.Control;
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.Image = global::Assessment.Properties.Resources.rsz_2arrow;
            this.btnBack.Location = new System.Drawing.Point(2, 1);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(63, 28);
            this.btnBack.TabIndex = 9;
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // ConstituenciesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(495, 279);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblCandidateDetails);
            this.Controls.Add(this.lstCandidates);
            this.Controls.Add(this.cmbConstituencies);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ConstituenciesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Constituencies";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ConstituenciesForm_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbConstituencies;
        private System.Windows.Forms.ListBox lstCandidates;
        private System.Windows.Forms.Label lblCandidateDetails;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnBack;
    }
}

