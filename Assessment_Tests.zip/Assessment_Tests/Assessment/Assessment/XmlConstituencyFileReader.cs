﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Linq;

namespace Assessment
{
    public class XmlConstituencyFileReader: IConstituencyFileReader
    {
        /// <summary>
        /// Reads the constituency and its details from the file 
        /// </summary>
        /// <param name="configRecord"></param>
        /// <returns>
        /// Returns a constituency object
        /// </returns>
        public Constituency ReadConstituencyDataFromFile(ConfigRecord configRecord)
        {
            // Open the file to read from the local file system
            // If this file is missing return immediately from this method
            if(!File.Exists(configRecord.Filename))
                {
                // cannot open the file as it does not exist for whatever reason, so return immediately
                return null;
            }

            // Open file and Load into memory as XML
            XDocument xmlDoc = XDocument.Load(configRecord.Filename);

            // try catch block to check whether it is a constituency xml file
            try
            {
                // Create constituency (should only be one per file)
                var ConstituencyName = (from c in xmlDoc.Descendants("Constituency")
                                        select c.Attribute("name").Value).First();

                Constituency constituency = new Constituency(ConstituencyName);

                // Debate create a candidate report for this constituency
                constituency.candidateList = new CandidateList();

                // Retrieve candidate details and add to the candidatereport
                // Local helper method used to select candidatedetails via LINQ query on XMLDocument
                constituency.candidateList.candidateDetails = SelectCandidateDetails(xmlDoc, ConstituencyName);

                // Local helper method to find the candidate with the highest vote
                constituency.candidatewinner = electedCandidate(xmlDoc, ConstituencyName);

                return constituency;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Extracts candidate's details from the xml document
        /// </summary>
        /// <param name="xmldoc"></param>
        /// <returns> a list of candidate details</returns>
        private List<CandidateDetails> SelectCandidateDetails(XDocument xmldoc, string constituencyName)
        {
            // Use Linq query to pick out the candidate's tags and order by votes
            var details = from candidate in xmldoc.Descendants("Candidate")
                            from firstname in candidate.Descendants("Firstname")
                            from lastname in candidate.Descendants("Lastname")
                            from votes in candidate.Descendants("Votes")
                            select new CandidateDetails(firstname.Value + " " + lastname.Value,
                            candidate.Attribute("party").Value, (int)votes, constituencyName);

            return details.ToList();
        }

        /// <summary>
        /// finds the candidate with the highest votes for a constituency
        /// </summary>
        /// <param name="xmldoc"></param>
        /// <returns> a candidate with the highest votes</returns>
        private CandidateDetails electedCandidate(XDocument xmldoc, string constituencyName)
        {
            // Using Linq query to find the candidate with the highest vote in each constituency
            var candidate = (from cnd in xmldoc.Descendants("Candidate")
                                from firstname in cnd.Descendants("Firstname")
                                from lastname in cnd.Descendants("Lastname")
                                from votes in cnd.Descendants("Votes")
                                orderby int.Parse(votes.Value) descending
                                select new CandidateDetails(firstname.Value + " " + lastname.Value,
                             cnd.Attribute("party").Value, (int)votes, constituencyName)).First();

            return (CandidateDetails)candidate;
        }        
    }
}
