﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Linq;

namespace Assessment
{
    public class XmlPartyReader:IPartyReader
    {
        /// <summary>
        /// Adds the votes for each party
        /// </summary>
        /// <param name="configRecord"></param>
        public List<Party> ReadParty(ConfigRecord configRecord)
        {
            // Open the file to read from the local file system
            // If this file is missing return immediately from this method
            if (!File.Exists(configRecord.Filename))
            {
                // cannot open the file as it does not exist for whatever reason, so return immediately
                return null;
            }

            // Open file and Load into memory as XML
            XDocument xmlDoc = XDocument.Load(configRecord.Filename);


            // Use Linq query to pick out the candidate's votes
            var parties = from candidate in xmlDoc.Descendants("Candidate")
                          from votes in candidate.Descendants("Votes")
                          select new Party(candidate.Attribute("party").Value, (int)votes);

            return parties.ToList();
        }
    }
}
