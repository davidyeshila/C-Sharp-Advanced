﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment
{
    public class PartyList
    {
        public List<Party> Parties;

        public PartyList()
        {            
            Parties = new List<Party>();
        }

        /// <summary>
        /// Overriding the String to display all the parties in the list with the total votes
        /// </summary>
        /// <returns> a string with all the parties and its votes</returns>
        public override string ToString()
        {
            string str = "Parties: " + Environment.NewLine;
            foreach (Party party in Parties)
            {
                str += party.ToString() + Environment.NewLine;
            }

            return str;
        }

        /// <summary>
        /// Add votes to the Party if it is part of the list else add the party to the list
        /// </summary>
        /// <param name="party"></param>
        public void AddVotes(Party party)
        {
            bool add = false;
            for(int i=0; i<Parties.Count; i++)
            {
                if (Parties[i].PartyName == party.PartyName)
                {
                    Parties[i].AddVotes(party.PartyVotes);
                    add = true;
                }                  
            }

            // Adds a new Party to the list
            if(add==false)
            {
                Parties.Add(party);
            }
            Parties = Parties.OrderByDescending(o => o.PartyVotes).ToList();
        }
    }
}
