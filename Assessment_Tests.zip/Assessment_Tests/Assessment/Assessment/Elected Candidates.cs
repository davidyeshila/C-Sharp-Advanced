﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment
{
    public partial class Elected_Candidates : Form
    {
        private ConstituencyList constituencyList;

        public Elected_Candidates(ConstituencyList constituencyList)
        {
            InitializeComponent();
            this.constituencyList = constituencyList;
        }

        /// <summary>
        /// the candidate winners from each constituency 
        /// is added to the lstElectedCandidates control
        /// </summary>
        private void Elected_Candidates_Load(object sender, EventArgs e)
        {
            foreach(var electedCandidate in constituencyList.constituencies)
            {
                lstElectedCandidates.Items.Add(electedCandidate.candidatewinner);
            }
        }

        /// <summary>
        /// if an elected candidate is selected then the details of the candidate is
        /// displayed in the label control
        /// </summary>
        private void lstElectedCandidates_SelectedIndexChanged(object sender, EventArgs e)
        {
            CandidateDetails candidDetails = (CandidateDetails)lstElectedCandidates.SelectedItem;
            lblDetails.Text = candidDetails.displayCandidate();
            
        }

        private void lblDetails_Click(object sender, EventArgs e)
        {

        }

        private void Elected_Candidates_FormClosed(object sender, FormClosedEventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
    }
}
