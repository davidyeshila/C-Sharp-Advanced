﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment
{
    public partial class ElectionWinnerForm : Form
    {
        PartyList partyList;
        public ElectionWinnerForm(PartyList partyList)
        {
            InitializeComponent();
            this.partyList=partyList;
        }

        /// <summary>
        /// Displays the election winner on load
        /// </summary>
        private void ElectionWinnerForm_Load(object sender, EventArgs e)
        {
            Party partyWinner = partyList.Parties.First();
            lblElectionWinner.Text = "The Winner of the General Election 2016 is"+Environment.NewLine+ partyWinner.PartyName +Environment.NewLine +"with " + partyWinner.PartyVotes+" votes";
        }

        private void ElectionWinnerForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
    }
}
